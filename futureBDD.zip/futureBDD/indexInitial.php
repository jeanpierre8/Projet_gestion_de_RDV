<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gestionnaire des rendez-vous Psy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">*
    <link rel="stylesheet" href="css\style.css">
</head>
<body>
<div class="container">
                <h1 class="text-center">
                <a   href="indexInitial.php">Gestionnaire des rendez-vous Psy</a>
                </h1>
                <h3 class="text-center">Identifiez-vous !!</h3>
                <button class="button button1"><a href="loginDOCTEUR.php">DOCTEUR</button>
				
				<button class="button button2"><a href="loginPATIENT.php">PATIENT</button>
				
				<button class="button button3"><a href="loginADMIN.php">ADMIN</button>

            </form>
        </div>
    </div>
</div>

</body>
</html>