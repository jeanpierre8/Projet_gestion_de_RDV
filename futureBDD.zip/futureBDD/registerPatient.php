<?php require_once 'controllers/authController.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insciption Patient</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">*
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1 class="text-center">
                <a   href="indexInitial.php">Gestionnaire des rendez-vous Psy</a>
                </h1>
    <div class="row">
        <div class="col-md-4 offset-md-4 form-div">
            <form action="registerPatient.php" method="post">
                <h3 class="text-center">Inscription</h3>
                
                <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <?php foreach($errors as $error):?>
                        <li><?php echo $error;?></li>
                        <?php endforeach;?>
                    </div>
                <?php endif;?>
                          
                <div class="form-group">
                    <label for="pseudo">Nom d'utilisateur :</label>
                    <input type="text" name="pseudo" value="<?php echo $pseudo;?>" class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="pseudo">Nom :</label>
                    <input type="text" name="nom"  class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="pseudo">Prénom :</label>
                    <input type="text" name="prénom"  class="form-control form-control-lg">
                </div>

                <!-- <div class="form-group">
                    <label for="pseudo">Profession :</label>
                    <input type="text" name="profession"  class="form-control form-control-lg">
                </div> -->
                
                <div class="form-group">
								<label class="block">
									Sexe :
								</label>
								<div class="clip-radio radio-primary">
									<input type="radio" id="rg-femme" name="genre" value="femme" >
									<label for="rg-female">
										Femme
									</label>
									<input type="radio" id="rg-homme" name="genre" value="homme">
									<label for="rg-male">
										Homme
									</label>
								</div>
                            </div>
                            
                            <div class="form-group">
								<label class="block">
									Situation familiale :
								</label>
								<div class="clip-radio radio-primary">
									<input type="radio" id="rg-Célibataire" name="Situ" value="Célibataire" >
									<label for="rg-Célibataire">
										Célibataire  
									</label>
									<input type="radio" id="rg-Adolescent" name="Situ" value="Adolescent">
									<label for="rg-Adolescent">
										Adolescent
                                    </label>
                                    <input type="radio" id="rg-couple" name="Situ" value="couple">
									<label for="rg-couple">
										En couple
                                    </label>
                                    <input type="radio" id="rg-Enfant" name="Situ" value="Enfant">
									<label for="rg-Enfant">
										Enfant
                                    </label>
                                    
								</div>
							</div>           

                <div class="form-group">

                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" name="email" value="<?php echo $email;?>"  class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="password">Mot de passe :</label>
                    <input type="password" name="password" class="form-control form-control-lg">
                </div>

                
                    <label for="mdpV">Confirmer mot de passe</label>
                    <input type="password" name="mdpV" class="form-control form-control-lg">
                </div>
                <div class="form-group">
                <button type="submit" name="register-btn" class="btn btn-primary btn-block btn-lg">S'inscrire</button>
                </div>
                <p class="text-center">Déja inscrit? <a href="loginPATIENT.php"> Connection</a></p>

            </form>
        </div>
    </div>
</div>

</body>
</html>