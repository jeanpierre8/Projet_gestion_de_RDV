<?php require_once 'controllers/authController.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insciption Patient</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">*
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1 class="text-center">
                <a   href="indexInitial.php">Gestionnaire des rendez-vous Psy</a>
                </h1>
    <div class="row">
        <div class="col-md-4 offset-md-4 form-div">
            <form action="registerPatient.php" method="post">
                <h3 class="text-center">Information complémentaire</h3>
                
                <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <?php foreach($errors as $error):?>
                        <li><?php echo $error;?></li>
                        <?php endforeach;?>
                    </div>
                <?php endif;?>
                          
                <div class="form-group">
                    <label for="pseudo">Profession :</label>
                    <input type="text" name="Profession" value="<?php echo $Profession;?>" class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="ProfessionA">Profession antérieur :</label>
                    <input type="text" name="ProfessionA"  class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="moyen">quel moyen vous connaissez la psy:</label>
                    <input type="text" name="moyen"  class="form-control form-control-lg">
                </div>
                
                <div class="form-group">
                <button type="submit" name="register-btn" class="btn btn-primary btn-block btn-lg">S'inscrire</button>
                </div>

            </form>
        </div>
    </div>
</div>

</body>
</html>