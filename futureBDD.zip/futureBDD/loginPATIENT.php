<?php require_once 'controllers/authController.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>S'identifier</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">*
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
                <h1 class="text-center">
                <a   href="indexInitial.php">Gestionnaire des rendez-vous Psy</a>
                </h1>
                <h3 class="text-center">Connexion pour le patient</h3>
    <div class="row">
        <div class="col-md-4 offset-md-4 form-div">
            <form action="loginPATIENT.php" method="post">
                <h3 class="text-center">S'identifier</h3>
                
                <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <?php foreach($errors as $error):?>
                        <li><?php echo $error;?></li>
                        <?php endforeach;?>
                    </div>
                <?php endif;?>

                
                <div class="form-group">
                    <label for="pseudo">Nom d'utilisateur ou Mail</label>
                    <input type="text" name="pseudo" value="<?php echo $pseudo;?>" class="form-control form-control-lg">
                </div>

                
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" name="password" class="form-control form-control-lg">
                </div>

                <div class="form-group">
                <button type="submit" name="login-btn" class="btn btn-primary btn-block btn-lg">Connection</button>
                </div>
                <p class="text-center">Pas encore inscrit? <a href="registerPatient.php">S'inscrire</a></p>

            </form>
        </div>
    </div>
</div>

</body>
</html>