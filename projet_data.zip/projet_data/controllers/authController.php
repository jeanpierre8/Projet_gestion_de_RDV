<?php 

session_start();
require 'config/datapass.php';
require 'emailController.php';
// initialiser pseudo et email
$errors = array();
$pseudo = "";
$email = "";

if (isset($_POST['register-btn'])){
$pseudo = $_POST['pseudo'];  
$email = $_POST['email'];
$password = $_POST['password'];
$mdpV = $_POST['mdpV'];


if (empty($pseudo)){
    $errors['pseudo']= "Pseudo requis!";
}
if (empty($email)){
    $errors['email']= "Email requis!";
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
    $errors['email']= "L'email est invalide";
}
if (empty($password)){
    $errors['password']= "Mot de passe requis!";
}

if ($password !== $mdpV){
    $errors['password']="Les mots de passe sont différents !";
    
}


$emailQuery = "SELECT * FROM user WHERE email=? LIMIT 1";
$stmt = $conn->prepare($emailQuery);
$stmt->bind_param('s', $email);
$stmt->execute();
$result=$stmt->get_result();
$userCount = $result->num_rows;
$stmt->close();

if ($userCount>0)
{$errors['email']="l'email a dèja été utilisé";
}

if (count($errors)===0){
    
    $clé_de_sécurité = bin2hex(random_bytes(20));
    $password= password_hash($password, PASSWORD_DEFAULT);
    $verifier=false;

    $sql = "INSERT INTO user(pseudo,email,password,verifier, clé_de_sécurité) VALUES(?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssds', $pseudo,$email,$password,$verifier,$clé_de_sécurité);

    if ($stmt->execute())
    {
    $user_id = $conn->insert_id;
    $_SESSION['idUser']=$user_id;
    $_SESSION['pseudo']=$pseudo;
    $_SESSION['email']=$email;
    $_SESSION['verifier']=$verifier;


    // sendVerificationEmail($email,$clé_de_sécurité);



    $_SESSION['message']='vous ete connecté';
    $_SESSION['alert-class']="alert-success";
    header('location: index.php');
    exit();

    }
    else{
        $errors['datapass_error']="Database error: failed to register";
    }
    
}
}

//boutton de login

if (isset($_POST['login-btn'])){
    $pseudo = $_POST['pseudo'];
    $password = $_POST['password'];
   
    
    if (empty($pseudo)){
        $errors['pseudo']= "Pseudo requis!";
    }
    
    if (empty($password)){
        $errors['password']= "Mot de passe requis!";
    }

   
    if (count($errors) === 0) {


        $sql = "SELECT * FROM user WHERE email=? OR pseudo=? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $pseudo, $pseudo);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        
        if (password_verify($password, $user['password'])) {
            // login success
            $_SESSION['idUser'] = $user['idUser'];
            $_SESSION['pseudo'] = $user['pseudo'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['verifier'] = $user['verifier'];
            // set flash message
            $_SESSION['message'] = "Vous êtes connecté!";
            $_SESSION['alert-class'] = "alert-success";
            header('location: index.php');
            exit();


        } else {
            $errors['login_fail'] = "Login fail";
        }
    }

    }


if (isset($_GET['logout'])){
    session_destroy();
    unset($_SESSION['idUser']);
    unset($_SESSION['username']);
    unset($_SESSION['email']);
    unset($_SESSION['verifier']);
    header('location: login.php');
    exit();
}

// function verifyUser($clé_de_sécurité){
//     global  $conn;
//     $sql = "SELECT * FROM user WHERE clé_de_sécurité='$clé_de_sécurité' LIMIT 1";
//     $result = mysqli_query($conn, $sql);

//     if(mysqli_num_rows($result) >0){
//         $user= mysqli_fetch_assoc($result);
//         $update_query = "UPDATE user SET verifier=1 WHERE clé_de_sécurité='$clé_de_sécurité'";

//         if(mysqli_query($conn,$update_query)){
//             $_SESSION['idUser'] = $user['idUser'];
//             $_SESSION['pseudo'] = $user['pseudo'];
//             $_SESSION['email'] = $user['email'];
//             $_SESSION['verifier'] = $user['verifier'];
//             // set flash message
//             $_SESSION['message'] = "Votre adresse est verifié!";
//             $_SESSION['alert-class'] = "alert-success";
//             header('location: index.php');
//             exit();
//         }
//     }
// else{
//     echo 'User not found';
// }
//}