<?php

// require_once 'vendor/autoload.php';
// require_once 'config/identifiant.php';
// // Create the Transport
// $transport = (new Swift_SmtpTransport('smtp.gmail.com', 465, 'ssl'))
//   ->setUsername('EMAIL')//gmail
//   ->setPassword('PASSWORD');

// // Create the Mailer using your created Transport
// $mailer = new Swift_Mailer($transport);




// function sendVerificationEmail($userEmail,$clé_de_sécurité)
// {
// global $mailer;
// $body='
// <
// <!DOCTYPE html>
// <html lang="en">
// <head>
//     <meta charset="UTF-8">
//     <title>Verification Email</title>
// </head>
// <body>
// <div class="wrapper">
// <p>
// Merci davoir sinscrip sur le notre site.
// </p>
// <a href="http://localhost/projet_data/index.php?clé_de_sécurité=' . $clé_de_sécurité. '">
// Verify your email adress
// </a>
// </div>
// </body>
// </html>';

// $message = (new Swift_Message('Verification de votre adresse mail'))
// ->setFrom(EMAIL)
// ->setTo($userEmail)
// ->setBody($body,'text/html');

// // Send the message
// $result = $mailer->send($message);

// }