<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'shoppsy');


// define('EMAIL','poubellebelle918@gmail.com');
// define('PASSWORD','poubelle7845/');