<?php

require 'identifiant.php';
$conn = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);

if($conn->connect_error){
    die('PROBLEME DE BASE DE DONNEE' . $conn->connect_error); 
}