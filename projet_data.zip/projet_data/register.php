<?php require_once 'controllers/authController.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insciption Patient</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">*
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 offset-md-4 form-div">
            <form action="register.php" method="post">
                <h3 class="text-center">Inscription</h3>
                
                <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <?php foreach($errors as $error):?>
                        <li><?php echo $error;?></li>
                        <?php endforeach;?>
                    </div>
                <?php endif;?>
                          
                <div class="form-group">
                    <label for="pseudo">Pseudo</label>
                    <input type="text" name="pseudo" value="<?php echo $pseudo;?>" class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" value="<?php echo $email;?>"  class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" name="password" class="form-control form-control-lg">
                </div>

                <div class="form-group">
                    <label for="mdpV">Confirmer mot de passe</label>
                    <input type="password" name="mdpV" class="form-control form-control-lg">
                </div>
                <div class="form-group">
                <button type="submit" name="register-btn" class="btn btn-primary btn-block btn-lg">S'inscrire</button>
                </div>
                <p class="text-center">Déja inscrit? <a href="login.php"> Connection</a></p>

            </form>
        </div>
    </div>
</div>

</body>
</html>