<?php 
require_once 'controllers/authController.php';

if (isset($_GET['clé_de_sécurité'])){
    $clé_de_sécurité=$_GET['clé_de_sécurité'];
    verifyUser($clé_de_sécurité);
}
if(!isset($_SESSION['idUser'])){
    header('location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shop PSY</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">*
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 offset-md-4 form-div">

        <?php if(isset($_SESSION['message'])): ?>
            <div class="alert <?php echo $_SESSION['alert-class'];?>">
            <?php 
            echo $_SESSION['message'];
            unset($_SESSION['message']);
            unset($_SESSION['alert-class']);

            ?>
        </div>
        <?php endif; ?>

        <h3>Bienvenu, <?php echo $_SESSION['pseudo'];?></h3>
        <a href="index.php?logout=1" class="logout">Déconnection</a>

        <?php if(!$_SESSION['verifier']): ?>
        <div class="alert alert-warning">
            Vous avez reçu un mail de confirmation pour verifier votre compte.
            Vous devez cliquer sur le lien de confirmation à <strong><?php echo $_SESSION['email'];?></strong>
        </div>
        <?php endif;?>

        <?php if($_SESSION['verifier']): ?> 
        <button class="btn btn-block btn-lg btn-primary">J'ai verifié</button>
        <?php endif;?>
        </div>
    </div>
</div>

</body>
</html>